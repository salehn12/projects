let currentQuestionindex = 0;
const quizQuestions = [
    { question: "wat is de hoofdstand van Nederland", options: ["Rotterdam", "Amsterdam", "Den haag"], correct: "Amsterdam" },
    { question: "wat is de hoofdstad van zuid-holland", options: ["Rotterdam", "Amsterdam", "Den haag"], correct: "Den haag" },
    { question: "wat is de hoofdstand van Noord-holland", options: ["Rotterdam", "haarlem", "Den haag"], correct: "haarlem" },
];
function displayQuestion() {

    const questionElement = document.getElementById('question');
    const optionsElement = document.getElementById('options');


    const currentQuestion = quizQuestions[currentQuestionindex];
    questionElement.textContent = currentQuestion.question;

    optionsElement.innerHTML = '';
    currentQuestion.options.forEach(options => {

        const button = document.createElement('button');
        button.textContent = options;
        button.addEventListener('click', () => checkAnswers(options));
        optionsElement.appendChild(button);
      
        


   
      





    })

}
displayQuestion();

