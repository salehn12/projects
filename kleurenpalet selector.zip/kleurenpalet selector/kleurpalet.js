let kleur= prompt("kies een cijfer van 1 tot met 5");
let shape= prompt("kies de shape");
 
let canvas = document.getElementById("myCanvas");
let ctx = canvas.getContext("2d");
const canvass = 50;

 
switch(kleur) {
case "1":
    console.log("Dit is de kleur rood");
    ctx.fillStyle = "red"; 
    ctx.fill
        break;
    case "2":
     console.log("Dit is de kleur blauw");
     ctx.fillStyle = "blue"; 
     ctx.fill
      break;
      case "3":
    console.log("Dit is de kleur geel");
    ctx.fillStyle = "yellow"; 
    ctx.fill
        break;
        case "4":
            console.log("Dit is de kleur oranje");
            ctx.fillStyle = "orange"; 
                break;
                case "5":
    console.log("Dit is de groen");
    ctx.fillStyle = "green"; 
    ctx.fill
        break;
        
        default:
            console.log("Onbekend kleur.");
    }


switch(shape){
case "driehoek": 
console.log("dit is de shape driehoek")
ctx.beginPath();
 
ctx.moveTo(100,20);
ctx.lineTo(180,100);
ctx.lineTo(20,100);
ctx.lineTo(100,20);
ctx.fill();

break;
case "vierkant":
    
ctx.rect(10, 10, 150, 100);
ctx.fill();

   break;
   case "cirkel" :
    ctx.beginPath();
ctx.arc(100, 75, 50, 0, 2 * Math.PI);

break;
case "rechthoek":
    ctx.beginPath();
    ctx.moveTo(50, 50); 
    ctx.lineTo(200, 50);
    ctx.lineTo(200, 150);
    ctx.lineTo(50, 150);
    ctx.lineTo(50, 50);
    ctx.fill();
    break;
    case "ster":
        ctx.beginPath();
        ctx.moveTo(150, 20); 
        ctx.lineTo(170, 80); 
        ctx.lineTo(210, 90); 
        ctx.lineTo(180, 120); 
        ctx.lineTo(190, 160); 
        ctx.lineTo(150, 140); 
        ctx.lineTo(110, 160); 
        ctx.lineTo(120, 120); 
        ctx.lineTo(90, 90); 
        ctx.lineTo(130, 80); 
          ctx.fill();
          break;
        
          default:
              console.log("Onbekend shape.");
}
