# Ctrl Alt Elite | Quiz

Kahoot type Quizz platform made in PHP
